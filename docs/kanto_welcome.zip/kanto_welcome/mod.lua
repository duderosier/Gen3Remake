-- Kanto Welcome Pack -- a small demonstration mod for Gen 3 Remake.
--
-- It shows the three things most Pokémon mods do:
--   1. change wild encounters      (api.wild)     -- Route 101 grass gets PIKACHU and EEVEE
--   2. change what an NPC says     (api.dialogue) -- the man in LITTLEROOT TOWN
--   3. add a one-time gift event   (api.quest)    -- 5 POKé BALLS when you first enter Route 101
--
-- Species / item ids are pret's (constants/species.h, constants/items.h):
--   PIKACHU 25, EEVEE 133, WURMPLE 290, POOCHYENA 286, ZIGZAGOON 288, POKE_BALL 4.
-- Maps: ROUTE 101 = group 0 map 16, LITTLEROOT TOWN = group 0 map 9.

local Q, W, D = api.quest, api.wild, api.dialogue

local ROUTE101    = { group = 0, map = 16 }
local LITTLEROOT  = { group = 0, map = 9 }
local FAT_MAN     = 2          -- LITTLEROOT TOWN object_events local_id
local FLAG_GIFT   = 0x0020     -- FLAG_UNUSED_0x020: nothing in the ROM uses it
local ITEM_POKE_BALL = 4

-- 1. Wild encounters: same 12-slot layout as the ROM (slot order = rarity,
--    the last slots are the rarest). Keep the natives, add the Kanto pair.
W.setArea(ROUTE101.group, ROUTE101.map, "land", {
    encounterRate = 20,
    mons = {
        { species = 290, minLevel = 2, maxLevel = 2 },   -- WURMPLE
        { species = 286, minLevel = 2, maxLevel = 2 },   -- POOCHYENA
        { species = 290, minLevel = 2, maxLevel = 3 },   -- WURMPLE
        { species = 286, minLevel = 2, maxLevel = 3 },   -- POOCHYENA
        { species = 288, minLevel = 3, maxLevel = 3 },   -- ZIGZAGOON
        { species = 288, minLevel = 3, maxLevel = 3 },   -- ZIGZAGOON
        { species = 25,  minLevel = 3, maxLevel = 4 },   -- PIKACHU
        { species = 25,  minLevel = 3, maxLevel = 4 },   -- PIKACHU
        { species = 288, minLevel = 2, maxLevel = 4 },   -- ZIGZAGOON
        { species = 133, minLevel = 3, maxLevel = 4 },   -- EEVEE
        { species = 133, minLevel = 4, maxLevel = 5 },   -- EEVEE (rare)
        { species = 25,  minLevel = 5, maxLevel = 5 },   -- PIKACHU (rare)
    },
})

-- 2. Dialogue: first matching entry wins, so the special line goes first
--    and the plain one is the fallback.
D.register(LITTLEROOT.group, LITTLEROOT.map, FAT_MAN, {
    { condition = { flag = FLAG_GIFT, value = true },
      text = "Did you use those POKé BALLS?\nI heard PIKACHU and EEVEE\nwandered in from KANTO!" },
    { condition = nil,
      text = "Strange POKéMON have been\nseen on ROUTE 101 lately…\nTake a look if you're going that way!" },
})

-- 3. One-time gift on entering Route 101. The flag is set FIRST so the
--    scene can never retrigger, even if something interrupts it.
Q.registerOnEnter(ROUTE101.group, ROUTE101.map, {
    { op = "setFlag", flag = FLAG_GIFT, value = true },
    { op = "msg",  text = "Something is tucked into the\ntall grass by the path…" },
    { op = "se",   name = "SE_PIN" },
    { op = "giveItem", item = ITEM_POKE_BALL, count = 5 },
    { op = "msg",  text = "Kanto Welcome Pack: PIKACHU and\nEEVEE now appear in the grass here." },
}, function() return not Q.getFlag(FLAG_GIFT) end)

return {
    name = "Kanto Welcome Pack",
    version = "1.0",
    init = function(a) a.log("Route 101 now has PIKACHU and EEVEE") end,
}
