# Kanto Welcome Pack (example mod)

Install: import `kanto_welcome.zip` from the launcher's MODS panel (Android: share the zip to the app),
or copy this folder to `<save dir>/mods/kanto_welcome/`.

What it does: PIKACHU and EEVEE in Route 101 grass, new lines for the man in Littleroot Town,
and 5 POKé BALLS the first time you enter Route 101. Read `mod.lua` — every line is commented.
